// Set the 'development' environment configuration object
module.exports = {
	db: 'mongodb://localhost/graphql-db-M2023',
	sessionSecret: 'developmentSessionSecret'
};