// define step activation function
function step(x) {
    return (x > 0) ? 1 : 0;
}

//
module.exports = step;
