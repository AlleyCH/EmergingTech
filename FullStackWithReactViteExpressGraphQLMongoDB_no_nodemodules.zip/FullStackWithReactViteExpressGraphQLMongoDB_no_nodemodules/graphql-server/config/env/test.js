// Set the 'test' environment configuration object
module.exports = {
	db: 'mongodb://localhost/crud-graphql-db-2023-test',
	sessionSecret: 'testSessionSecret'
};