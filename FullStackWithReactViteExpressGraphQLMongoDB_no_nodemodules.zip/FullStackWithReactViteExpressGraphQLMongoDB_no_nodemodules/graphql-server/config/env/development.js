// Set the 'development' environment configuration object
module.exports = {
	db: 'mongodb://localhost/crud-graphql-db-2023',
	sessionSecret: 'developmentSessionSecret'
};