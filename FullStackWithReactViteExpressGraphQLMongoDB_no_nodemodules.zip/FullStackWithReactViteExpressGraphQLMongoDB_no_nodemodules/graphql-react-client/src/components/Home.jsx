
import React  from 'react';

function Home(props)
{


    return (
        <div>
            <h2> Express - GraphQL - React with CRUD Operations</h2>
            <p>React front-end calls Express GraphQL API to add, 
            list, update, or delete.</p>
        </div>
    );

}

export default Home;