import CourseList from "./CourseList";
//
function App() {
  return (
    <div className="App">
      <CourseList />
    </div>
  );
}
//
export default App;
